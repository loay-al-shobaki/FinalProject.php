package com.example.restaurant.admin

import BaseFragment

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation.findNavController
import com.example.restaurant.R
import com.example.restaurant.database.RecipeImp
import com.example.restaurant.databinding.FragmentAdminBinding
import com.example.restaurant.search.model.Recipe
import com.example.restaurant.toList


class EnterDataAdminFragment : BaseFragment<FragmentAdminBinding>() {
    val recipeData = RecipeImp()
    lateinit var recipe_obj: Recipe

    override val inflater: (LayoutInflater, ViewGroup?, Boolean) -> FragmentAdminBinding =
        FragmentAdminBinding::inflate

    override fun setUp() {
    }

    override fun addCallBacks() {
        binding.run {

            btnAddToDatabase.setOnClickListener {
                recipe_obj = Recipe("",
                    editTxtName.text.toString(),
                    editTxtIngredients.text.toString().toList(),
                    editTxtTime.text.toString().toInt(),
                    editTxtCuisine.text.toString(),
                    editTxtInstruction.text.toString().toList(),
                    editTxtSourceUrl.text.toString(),
                    editTxtCleanIngredients.text.toString().toList(),
                    editTxtImgUrl.text.toString(),
                    ratingBar.rating,
                    editTxtPrice.text.toString().toFloat()

                )
                addRecipetoDataBase(recipe_obj)
            }

            btnUpDateRecipeToDatabase.setOnClickListener {
                findNavController(it).navigate(R.id.action_adminFragment_to_showRecipeAdminFragment)
            }

        }
    }


    fun addRecipetoDataBase(recipe: Recipe) {
        recipeData.addRecioeToDataBase(recipe)
    }







}