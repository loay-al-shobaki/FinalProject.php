package com.example.restaurant.login

import BaseFragment
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.restaurant.R
import com.example.restaurant.database.UserImp
import com.example.restaurant.databinding.FragmentLoginBinding
import com.example.restaurant.localData.SharedPrefs
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class Login : BaseFragment<FragmentLoginBinding>() {
    val userData = UserImp()


    override val inflater: (LayoutInflater, ViewGroup?, Boolean) -> FragmentLoginBinding =
        FragmentLoginBinding::inflate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       if (SharedPrefs.isTheUserIdIsFound(requireContext())){
           findNavController().navigate(R.id.action_login_to_homeActivity)

        }
    }
    override fun setUp() {


    }

    override fun addCallBacks() {
        binding.btnlogin.setOnClickListener { v ->
            lifecycleScope.launch {
                val id = userData.getIdIfUersIfExist(
                    binding.txtEmail.text.toString(),
                    binding.txtPassword.text.toString()
                )
                var x =  userData.getDataUserDatabaseById(id)
                SharedPrefs.saveUserDataToPrefs(requireContext(), x[0])

                if (id.isNotEmpty()) {
                    SharedPrefs.saveUserIdoPrefs(requireContext(),id)
                    findNavController(v).navigate(R.id.action_login_to_homeActivity)
                }
            }

        }

        binding.textViewSignup.setOnClickListener { v ->
            findNavController(v).navigate(R.id.action_login_to_signup)

        }

        binding.txtAdmin.setOnClickListener { v ->
            findNavController(v).navigate(R.id.action_login_to_loginAdmin)

        }
    }


}