package com.example.restaurant.localData.domin

data class HomeItem<T>(
    val item:T,
    val type:HomeItemType
)