package com.example.restaurant.localData.domin

enum class HomeItemType {
    TYPE_MAIN_RECIPE,
    TYPE_RATING_RECIPE,
    TYPE_MOSTNEED_RECIPE

}