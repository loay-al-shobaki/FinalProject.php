package com.example.restaurant.setting

import BaseFragment
import android.content.DialogInterface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.restaurant.R
import com.example.restaurant.database.UserImp
import com.example.restaurant.databinding.FragmentSettingBinding
import com.example.restaurant.localData.SharedPrefs
import com.example.restaurant.localData.SharedPrefs.getUserIdFromPrefs
import com.example.restaurant.search.model.Users
import com.example.restaurant.showConfirmationDialog
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingFragment : BaseFragment<FragmentSettingBinding>() {

    private lateinit var editTextDate: TextInputEditText
    private lateinit var dateFormatter: SimpleDateFormat
    val userData = UserImp()
    private val contract =registerForActivityResult(ActivityResultContracts.GetContent()){
        binding.imageprofile.setImageURI(it)
    }
    override val inflater: (LayoutInflater, ViewGroup?, Boolean) -> FragmentSettingBinding =
        FragmentSettingBinding::inflate

    override fun setUp() {

        editTextDate = binding.editTextDate
        dateFormatter = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        editTextDate.setOnClickListener {
            showDatePicker()
        }

        lifecycleScope.launch {
            val userdata = userData.getDataUserDatabaseById(getUserIdFromPrefs(requireContext()))
            getCurrentdata(userdata[0])
        }


    }

    override fun addCallBacks() {
        binding.btnsubmit.setOnClickListener {
            lifecycleScope.launch {
                if (userData.updateUserdata(
                        getUserIdFromPrefs(requireContext()),
                        changedata(),
                        binding.txtConfirmpassword.text.toString()
                    )
                ) {
                    Toast.makeText(context, "User data updated successfully!", Toast.LENGTH_SHORT)
                        .show()
                } else Toast.makeText(context, "Error updating user data!", Toast.LENGTH_SHORT)
                    .show()
            }

        }

        binding.txtsignout.setOnClickListener {
            SharedPrefs.clearTextInSharedPreferences(requireContext())
            onClickDeleteRecipe()
        }
        binding.editTextLocation.setOnClickListener {
            findNavController().navigate(R.id.action_action_setting_to_mapUserFragment2)
        }
        binding.imageprofile.setOnClickListener {
            contract.launch("image/*")
        }



    }

    fun changedata(): Users {
        return Users(
            "",
            binding.txtnameold.text.toString(),
            binding.txtEmailold.text.toString(),
            binding.txtpasswordold.text.toString(),
            binding.editTextDate.text.toString(),
            binding.editTextLocation.text.toString()
        )
    }

    fun getCurrentdata(user: Users){
        binding.txtnameold.setText(user.name)
        binding.txtEmailold.setText(user.email)
        binding.txtpasswordold.setText(user.password)
        binding.editTextDate.setText(user.dateOfBirth)
        binding.editTextLocation.setText(user.location)
    }



     fun onClickDeleteRecipe() {
        context?.showConfirmationDialog(
            "Confirmation",
            "Are you sure you want to sign out?",
            positiveButtonListener,
            negativeButtonListener
        )


    }


    private val positiveButtonListener =
        DialogInterface.OnClickListener { dialog, which ->
            SharedPrefs.clearTextInSharedPreferences(requireContext())
            Log.d("loay", "${SharedPrefs.isTheUserIdIsFound(requireContext())} ")
            findNavController().navigate(R.id.action_action_setting_to_mainActivity)

        }

    private val negativeButtonListener =
        DialogInterface.OnClickListener { dialog, which ->

        }

    private fun showDatePicker() {
        val calendarConstraintsBuilder = CalendarConstraints.Builder()
        val datePickerBuilder = MaterialDatePicker.Builder.datePicker()
        datePickerBuilder.setTitleText("Select a date")
        datePickerBuilder.setCalendarConstraints(calendarConstraintsBuilder.build())
        val materialDatePicker = datePickerBuilder.build()
        materialDatePicker.addOnPositiveButtonClickListener { selectedDate ->
            val formattedDate: String = dateFormatter.format(Date(selectedDate))
            binding.editTextDate.setText(formattedDate)
        }
        materialDatePicker.show(requireActivity().supportFragmentManager, "DATE_PICKER")
    }

}