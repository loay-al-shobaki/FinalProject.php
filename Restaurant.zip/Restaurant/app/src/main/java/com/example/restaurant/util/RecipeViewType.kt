package com.example.restaurant.util

enum class RecipeViewType {
    TYPE_HEADER, ITEM_INGREDIENT
}